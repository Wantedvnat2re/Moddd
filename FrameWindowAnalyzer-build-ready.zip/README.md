# Frame Window Analyzer

Geode mod project targeting Geode SDK 5.11.2, Geometry Dash Android 2.2081, and Android64. The source archive is a **development build**, not a claim that every requested in-game feature is complete.

## Implemented and tested in this project

- Recording event model: press/release records, pause/resume/stop, CSV save/load with transactional validation and event caps, edit/delete/shift operations.
- Timing statistics over supplied traces (counts, duration, mean/median intervals, measured processing speed). These are descriptive statistics, not survivability windows.
- Route planner over caller-supplied time intervals, with monotonic/minimum-gap constraints, candidate validation, bounded search, validation and CSV export. It does not derive game-safe intervals itself.
- Persistent configuration serialization with input validation and temporary-file replacement.
- A basic Geode main-menu entry point and GitHub Actions Android64 build definition.

## Not yet complete / not claimed

This project does **not** yet provide a complete production mod. In particular, it does not currently have an integrated in-game input capture hook, a complete functional Geode UI for every requested screen, playback integrated with supported game input APIs, a Geometry Dash physics/state simulator, or authoritative safe-frame window detection. The four profile values are accepted by the descriptive analyzer but do not perform four distinct gameplay scans. `MissingOnly` is not a persisted/incremental gameplay scan. A route is trustworthy only if the caller supplies authoritative validated candidate intervals; the standalone planner cannot create that evidence.

These limitations matter: a click timestamp alone cannot establish whether an action survives a hazard. The mod must not label inferred timings as safe or verified. A compatible Geode SDK build also cannot be certified in this workspace because the SDK/toolchain is not installed here.

## Standalone core tests

From the project root:

```sh
g++ -std=c++17 -Wall -Wextra -Werror -Iinclude \
  tests/core_tests.cpp src/analyzer/FrameAnalyzer.cpp src/recorder/Recording.cpp \
  src/pathfinder/Pathfinder.cpp src/utils/Config.cpp -o /tmp/fwa-core-tests
/tmp/fwa-core-tests
```

## Android64 build

The workflow at `.github/workflows/build.yml` builds only Android64, checks that a non-empty `.geode` was emitted, and uploads the mod, source ZIP, and a verification log. This repository has not yet passed a real build against the hosted Geode SDK; treat the first GitHub Actions run as the authoritative toolchain check. A successful archive packaging step alone is not a successful mod build.

## Build locally (Android64)

The repository includes `build-android64.sh`. On Linux/macOS with Geode CLI and Android NDK installed, run:

```sh
./build-android64.sh
```

The script installs the Geode 5.11.2 Android64 binaries and invokes `geode build -p android64`. The resulting `.geode` package is written under the build directory. Alternatively, use the GitHub Actions workflow in `.github/workflows/build.yml`; push the **extracted project contents** to the repository root (not just the ZIP file), then run the workflow from the Actions tab or push to `main`.

A successful compilation only verifies that the current source builds. It does not imply that the in-game features listed in the roadmap are already implemented; see **Not yet complete / not claimed** above.
