#include "fwa/analyzer/FrameAnalyzer.hpp"
#include "fwa/pathfinder/Pathfinder.hpp"
#include "fwa/recorder/Recording.hpp"
#include "fwa/utils/Config.hpp"
#include <cassert>
#include <cstdio>
#include <string>
#include <vector>
int main() {
    using namespace fwa;
    Recording r; r.begin(); r.add({100,1,0,true,1}); r.add({200,2,0,false,1}); r.add({300,3,0,true,2});
    r.pause(); r.add({400,4,0,true,1}); assert(r.events().size()==3); r.resume(); r.stop();
    std::string error; const std::string path="fwa-core-test.csv"; assert(r.saveCsv(path,error));
    Recording loaded; assert(loaded.loadCsv(path,error)); assert(loaded.events().size()==3); assert(loaded.events()[2].player==2);
    assert(loaded.shiftFrom(1,50,error)); assert(loaded.events()[1].timestampNs==250);
    assert(loaded.edit(1,{220,2,1,false,1},error)); assert(loaded.erase(0,error)); std::remove(path.c_str());
    std::vector<ClickSample> events{{0,0,0,true,1},{100000000,6,0,false,1},{300000000,18,0,true,1}};
    auto stats=FrameAnalyzer::analyzeRecordedTiming(events,60.0,ScanProfile::Balanced);
    assert(stats.inputEvents==3 && stats.clickPresses==2 && stats.releases==1 && stats.windows.size()==2);
    assert(!stats.windows.front().verified && stats.meanIntervalMs>0 && stats.medianIntervalMs>0 && stats.durationNs==300000000);
    auto invalid=FrameAnalyzer::analyzeRecordedTiming(events,0.0,ScanProfile::Accurate); assert(invalid.invalidEvents==events.size());
    std::vector<std::vector<CandidateWindow>> stages{{{100,10,0.9,true}},{{200,20,0.8,true}}};
    auto route=Pathfinder::findRoute(stages,50); assert(route.found && route.steps.size()==2);
    assert(Pathfinder::validateRoute(stages,route,50,error));
    assert(Pathfinder::saveRouteCsv("fwa-route-test.csv",route,error)); std::remove("fwa-route-test.csv");
    Config cfg; cfg.fps=120; assert(cfg.save("fwa-config-test.json",error)); auto cfg2=Config::load("fwa-config-test.json");
    assert(cfg2.fps==120); std::remove("fwa-config-test.json");
    return 0;
}
