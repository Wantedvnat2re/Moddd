# Core tests

The tests exercise recording round-trips, edit operations, event ordering, timing statistics, and invalid FPS handling.

Run standalone from the project root:

```sh
g++ -std=c++17 -Wall -Wextra -Werror -Iinclude tests/core_tests.cpp src/analyzer/FrameAnalyzer.cpp src/recorder/Recording.cpp -o /tmp/fwa-core-tests && /tmp/fwa-core-tests
```

They do not claim gameplay simulation or survivability-window validation; that requires an authoritative game-state/replay interface.
