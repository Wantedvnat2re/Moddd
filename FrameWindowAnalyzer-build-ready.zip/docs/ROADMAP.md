# Development status

## Foundation
- [x] Geode project metadata and Android64 workflow definition
- [x] Recording data model with CSV round-trip and editing operations
- [x] Timing-data validation and descriptive statistics
- [x] Standalone core test coverage
- [ ] Verify build against the actual Geode 5.11.2 Android64 toolchain

## Not yet implemented
- [ ] Inspect Geode 5.11.2 bindings for supported input/gameplay hooks
- [ ] Capture press/release events without blocking the game thread
- [ ] Persist versioned recording files atomically
- [ ] Establish a supported deterministic replay/state-evaluation method
- [ ] Implement actual profile-specific scan strategies and Missing Only / From Scratch analysis
- [ ] Add asynchronous progress, cancellation, and persistence
- [ ] Build functional Record, Analyze, Playback, Pathfinder, Insights, Import/Export, Click Editor, and Settings interfaces
- [ ] Validate Android UI scaling and touch behavior

The analyzer is intentionally limited to statistics over provided event traces. It must not report safe frame windows or successful routes without authoritative game-state validation.
