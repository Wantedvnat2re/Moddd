#include "fwa/utils/Config.hpp"
#include <cmath>
#include <fstream>
#include <sstream>

namespace fwa {
namespace {
template<class T> bool readValue(const std::string& text, const char* key, T& out) {
    const auto pos = text.find(std::string("\"") + key + "\""); if (pos == std::string::npos) return false;
    const auto colon = text.find(':', pos); if (colon == std::string::npos) return false;
    std::istringstream stream(text.substr(colon + 1)); T candidate{}; if (!(stream >> candidate)) return false; out = candidate; return true;
}
bool readBool(const std::string& text, const char* key, bool& out) {
    const auto pos = text.find(std::string("\"") + key + "\""); if (pos == std::string::npos) return false;
    const auto colon = text.find(':', pos); if (colon == std::string::npos) return false;
    auto value = text.find_first_not_of(" \t\r\n", colon + 1); if (value == std::string::npos) return false;
    if (text.compare(value, 4, "true") == 0) { out = true; return true; }
    if (text.compare(value, 5, "false") == 0) { out = false; return true; } return false;
}
}
Config Config::load(const std::string& path) {
    Config c; std::ifstream f(path); if (!f) return c;
    std::ostringstream buffer; buffer << f.rdbuf(); const auto text = buffer.str();
    readValue(text, "scanProfile", c.scanProfile); readValue(text, "fps", c.fps);
    readBool(text, "adaptive", c.adaptive); readBool(text, "capturePlayer1", c.capturePlayer1);
    readBool(text, "capturePlayer2", c.capturePlayer2); readBool(text, "autoSave", c.autoSave);
    if (c.scanProfile < 0 || c.scanProfile > 3) c.scanProfile = 2;
    if (!std::isfinite(c.fps) || c.fps < 1.0 || c.fps > 1000.0) c.fps = 60.0;
    return c;
}
bool Config::save(const std::string& path, std::string& error) const {
    if (scanProfile < 0 || scanProfile > 3 || !std::isfinite(fps) || fps < 1.0 || fps > 1000.0) { error = "Invalid configuration values"; return false; }
    const std::string temporary = path + ".tmp"; std::ofstream f(temporary, std::ios::trunc);
    if (!f) { error = "Cannot open temporary configuration file"; return false; }
    f << "{\n  \"scanProfile\": " << scanProfile << ",\n  \"fps\": " << fps << ",\n  \"adaptive\": " << (adaptive ? "true" : "false") << ",\n  \"capturePlayer1\": " << (capturePlayer1 ? "true" : "false") << ",\n  \"capturePlayer2\": " << (capturePlayer2 ? "true" : "false") << ",\n  \"autoSave\": " << (autoSave ? "true" : "false") << "\n}\n";
    f.close(); if (!f.good()) { error = "Failed writing configuration"; return false; }
    if (std::rename(temporary.c_str(), path.c_str()) != 0) { error = "Cannot replace configuration file"; std::remove(temporary.c_str()); return false; }
    return true;
}
} // namespace fwa
