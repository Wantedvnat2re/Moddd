#include <Geode/Geode.hpp>
#include <Geode/modify/MenuLayer.hpp>

using namespace geode::prelude;

class $modify(FWA_MenuLayer, MenuLayer) {
    bool init() {
        if (!MenuLayer::init()) return false;

        // Keep the entry point conservative: if the expected menu is absent,
        // the mod still loads instead of crashing the main menu.
        auto menu = this->getChildByID("bottom-menu");
        if (menu) {
            auto sprite = ButtonSprite::create("FWA");
            auto button = CCMenuItemSpriteExtra::create(
                sprite, this, menu_selector(FWA_MenuLayer::openAnalyzer)
            );
            button->setID("fwa-open-button");
            menu->addChild(button);
            menu->updateLayout();
        }
        return true;
    }

    void openAnalyzer(CCObject*) {
        FLAlertLayer::create(
            "Frame Window Analyzer",
            "Development build 0.1.0\\n"
            "The analysis core and recording model are being implemented.\\n"
            "No gameplay window is reported until a verified measurement source exists.",
            "Close"
        )->show();
    }
};
