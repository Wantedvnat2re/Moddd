#include "fwa/pathfinder/Pathfinder.hpp"
#include <algorithm>
#include <cmath>
#include <fstream>
#include <limits>

namespace fwa {
namespace {
struct State { std::size_t candidate; std::uint64_t time; double score; std::vector<RouteStep> route; };
std::uint64_t low(const CandidateWindow& w) { return w.centerNs > w.halfWidthNs ? w.centerNs - w.halfWidthNs : 0; }
std::uint64_t high(const CandidateWindow& w) { return w.centerNs > std::numeric_limits<std::uint64_t>::max() - w.halfWidthNs ? std::numeric_limits<std::uint64_t>::max() : w.centerNs + w.halfWidthNs; }
}
RouteResult Pathfinder::findRoute(const std::vector<std::vector<CandidateWindow>>& stages, std::uint64_t gap, bool allowUnvalidated, std::size_t maxStates) {
    RouteResult result;
    if (stages.empty() || maxStates == 0) { result.status = "empty-input"; return result; }
    std::vector<State> states;
    for (std::size_t i = 0; i < stages[0].size(); ++i) {
        const auto& w = stages[0][i];
        if ((!allowUnvalidated && !w.validated) || !std::isfinite(w.confidence)) continue;
        const double confidence = std::max(0.0, std::min(1.0, w.confidence));
        states.push_back({i, low(w), confidence, {{i, low(w)}}});
        if (states.size() >= maxStates) break;
    }
    if (states.empty()) { result.status = "no-eligible-candidates"; return result; }
    std::size_t examined = states.size();
    for (std::size_t stage = 1; stage < stages.size(); ++stage) {
        std::vector<State> next;
        for (const auto& prev : states) for (std::size_t i = 0; i < stages[stage].size(); ++i) {
            const auto& w = stages[stage][i];
            if ((!allowUnvalidated && !w.validated) || !std::isfinite(w.confidence)) continue;
            const auto earliest = prev.time > std::numeric_limits<std::uint64_t>::max() - gap ? std::numeric_limits<std::uint64_t>::max() : prev.time + gap;
            const auto chosen = std::max(earliest, low(w));
            if (chosen > high(w)) continue;
            auto route = prev.route; route.push_back({i, chosen});
            const double confidence = std::max(0.0, std::min(1.0, w.confidence));
            next.push_back({i, chosen, prev.score + confidence, std::move(route)});
            if (++examined >= maxStates) break;
        }
        if (next.empty()) { result.status = examined >= maxStates ? "state-limit" : "no-monotonic-route"; return result; }
        if (examined >= maxStates && stage + 1 < stages.size()) { result.status = "state-limit"; return result; }
        // Keep the best state per endpoint time/candidate. Bound memory via maximumStates.
        std::sort(next.begin(), next.end(), [](const State& a, const State& b) { return a.score > b.score; });
        if (next.size() > maxStates) next.resize(maxStates);
        states.swap(next);
    }
    const auto best = std::max_element(states.begin(), states.end(), [](const State& a, const State& b) { return a.score < b.score; });
    result.found = true; result.score = best->score; result.steps = best->route; result.status = allowUnvalidated ? "route-found-validation-not-guaranteed" : "route-found-from-validated-candidates";
    return result;
}
bool Pathfinder::validateRoute(const std::vector<std::vector<CandidateWindow>>& stages, const RouteResult& route, std::uint64_t gap, std::string& error) {
    if (!route.found || route.steps.size() != stages.size()) { error = "Route does not cover all stages"; return false; }
    std::uint64_t previous = 0;
    for (std::size_t s = 0; s < stages.size(); ++s) {
        const auto& step = route.steps[s];
        if (step.sourceIndex >= stages[s].size()) { error = "Route references a missing candidate"; return false; }
        const auto& w = stages[s][step.sourceIndex];
        if (!w.validated || step.chosenTimeNs < low(w) || step.chosenTimeNs > high(w)) { error = "Route uses an unvalidated or out-of-window candidate"; return false; }
        if (s && (step.chosenTimeNs < previous || step.chosenTimeNs - previous < gap)) { error = "Route violates monotonic gap constraint"; return false; }
        previous = step.chosenTimeNs;
    }
    return true;
}
bool Pathfinder::saveRouteCsv(const std::string& path, const RouteResult& route, std::string& error) {
    if (!route.found || route.steps.empty()) { error = "Cannot save an empty route"; return false; }
    std::ofstream f(path, std::ios::trunc); if (!f) { error = "Cannot open route file"; return false; }
    f << "stage,candidate_index,chosen_time_ns\n";
    for (std::size_t i = 0; i < route.steps.size(); ++i) f << i << ',' << route.steps[i].sourceIndex << ',' << route.steps[i].chosenTimeNs << '\n';
    if (!f.good()) { error = "Failed writing route file"; return false; }
    return true;
}
} // namespace fwa
