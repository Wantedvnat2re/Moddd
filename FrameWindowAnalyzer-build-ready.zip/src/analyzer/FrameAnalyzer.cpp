#include "fwa/analyzer/FrameAnalyzer.hpp"
#include <algorithm>
#include <chrono>
#include <cmath>

namespace fwa {

const char* FrameAnalyzer::profileName(ScanProfile profile) {
    switch (profile) {
        case ScanProfile::Fastest: return "Fastest";
        case ScanProfile::Fast: return "Fast";
        case ScanProfile::Balanced: return "Balanced";
        case ScanProfile::Accurate: return "Accurate";
    }
    return "Balanced";
}

AnalysisSummary FrameAnalyzer::analyzeRecordedTiming(const std::vector<ClickSample>& events, double fps, ScanProfile profile) {
    AnalysisOptions options; options.fps = fps; options.profile = profile;
    return analyze(events, options);
}

AnalysisSummary FrameAnalyzer::analyze(const std::vector<ClickSample>& events, const AnalysisOptions& options,
                                        const std::vector<WindowResult>& previous) {
    AnalysisSummary out;
    const auto started = std::chrono::steady_clock::now();
    out.inputEvents = events.size();
    if (!std::isfinite(options.fps) || options.fps <= 0.0 || events.size() > options.maximumEvents) {
        out.invalidEvents = events.size(); return out;
    }
    std::vector<std::uint64_t> intervals;
    intervals.reserve(events.size());
    std::uint64_t previousTime = 0;
    std::uint64_t firstValidTime = 0;
    std::uint64_t lastValidTime = 0;
    bool first = true;
    const auto frameNs = static_cast<std::uint64_t>(1'000'000'000.0 / options.fps);
    std::size_t stepFrames = 1;
    switch (options.profile) {
        case ScanProfile::Fastest: stepFrames = 8; break;
        case ScanProfile::Fast: stepFrames = 4; break;
        case ScanProfile::Balanced: stepFrames = 2; break;
        case ScanProfile::Accurate: stepFrames = 1; break;
    }
    for (const auto& event : events) {
        if (event.player < 1 || event.player > 2 || (!first && event.timestampNs < previousTime)) {
            ++out.invalidEvents; continue;
        }
        if (!first) intervals.push_back(event.timestampNs - previousTime);
        else firstValidTime = event.timestampNs;
        previousTime = event.timestampNs;
        lastValidTime = event.timestampNs;
        first = false;
        if (event.pressed) ++out.clickPresses; else ++out.releases;
    }
    if (!first) out.durationNs = lastValidTime - firstValidTime;
    if (!intervals.empty()) {
        long double sum = 0;
        for (auto ns : intervals) sum += ns;
        out.meanIntervalMs = static_cast<double>(sum / intervals.size() / 1'000'000.0L);
        auto sorted = intervals; std::sort(sorted.begin(), sorted.end());
        const auto n = sorted.size();
        out.medianIntervalMs = (n % 2) ? sorted[n / 2] / 1'000'000.0
            : (sorted[n / 2 - 1] / 2'000'000.0 + sorted[n / 2] / 2'000'000.0);
    }
    // Timing traces only locate recorded event centers; no game-state simulator is available,
    // therefore they cannot establish survivability or true gameplay windows.
    for (const auto& event : events) {
        if (!event.pressed || event.player < 1 || event.player > 2) continue;
        WindowResult result; result.centerNs = event.timestampNs;
        result.widthNs = 0; result.widthFrames = 0; result.widthMs = 0;
        result.verified = false; result.status = "recorded-time-only";
        out.windows.push_back(result);
    }
    if (options.mode == ReanalysisMode::MissingOnly) {
        auto isPreviouslyPresent = [&previous](std::uint64_t center) {
            return std::any_of(previous.begin(), previous.end(), [center](const WindowResult& item) {
                return item.centerNs == center;
            });
        };
        out.windows.erase(std::remove_if(out.windows.begin(), out.windows.end(),
            [&isPreviouslyPresent](const WindowResult& item) { return isPreviouslyPresent(item.centerNs); }), out.windows.end());
    }
    (void)frameNs; (void)stepFrames;
    const auto elapsed = std::chrono::duration<double>(std::chrono::steady_clock::now() - started).count();
    out.measuredEventsPerSecond = elapsed > 0 ? events.size() / elapsed : 0;
    return out;
}

} // namespace fwa
