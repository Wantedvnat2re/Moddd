#include "fwa/recorder/Recording.hpp"
#include <algorithm>
#include <fstream>
#include <limits>
#include <sstream>

namespace fwa {
namespace {
constexpr std::size_t kMaxEvents = 2'000'000;
}

void Recording::begin() { m_events.clear(); m_recording = true; m_paused = false; }
void Recording::pause() { if (m_recording) m_paused = true; }
void Recording::resume() { if (m_recording) m_paused = false; }
void Recording::stop() { m_recording = false; m_paused = false; }
bool Recording::isRecording() const { return m_recording; }
bool Recording::isPaused() const { return m_paused; }
void Recording::add(ClickSample sample) {
    if (m_recording && !m_paused && m_events.size() < kMaxEvents &&
        (m_events.empty() || sample.timestampNs >= m_events.back().timestampNs))
        m_events.push_back(sample);
}

bool Recording::edit(std::size_t index, ClickSample sample, std::string& error) {
    if (index >= m_events.size()) { error = "Event index is out of range"; return false; }
    if ((index && sample.timestampNs < m_events[index - 1].timestampNs) ||
        (index + 1 < m_events.size() && sample.timestampNs > m_events[index + 1].timestampNs)) {
        error = "Edited timestamp must preserve event order"; return false;
    }
    m_events[index] = sample;
    return true;
}
bool Recording::erase(std::size_t index, std::string& error) {
    if (index >= m_events.size()) { error = "Event index is out of range"; return false; }
    m_events.erase(m_events.begin() + static_cast<std::ptrdiff_t>(index)); return true;
}
bool Recording::shiftFrom(std::size_t index, std::int64_t deltaNs, std::string& error) {
    if (index >= m_events.size()) { error = "Event index is out of range"; return false; }
    auto candidate = m_events;
    for (std::size_t i = index; i < candidate.size(); ++i) {
        const auto old = candidate[i].timestampNs;
        const std::uint64_t magnitude = deltaNs < 0
            ? static_cast<std::uint64_t>(-(deltaNs + 1)) + 1
            : static_cast<std::uint64_t>(deltaNs);
        if (deltaNs < 0 && old < magnitude) { error = "Shift would make timestamp negative"; return false; }
        if (deltaNs > 0 && old > std::numeric_limits<std::uint64_t>::max() - magnitude) { error = "Timestamp overflow"; return false; }
        candidate[i].timestampNs = deltaNs < 0 ? old - magnitude : old + magnitude;
    }
    m_events.swap(candidate); return true;
}
const std::vector<ClickSample>& Recording::events() const { return m_events; }

bool Recording::saveCsv(const std::string& path, std::string& error) const {
    std::ofstream file(path, std::ios::out | std::ios::trunc);
    if (!file) { error = "Cannot open recording output file"; return false; }
    file << "timestamp_ns,frame,substep,pressed,player\n";
    for (const auto& e : m_events)
        file << e.timestampNs << ',' << e.frame << ',' << e.substep << ',' << (e.pressed ? 1 : 0) << ',' << static_cast<unsigned>(e.player) << '\n';
    if (!file.good()) { error = "Failed while writing recording"; return false; }
    return true;
}

bool Recording::loadCsv(const std::string& path, std::string& error) {
    std::ifstream file(path);
    if (!file) { error = "Cannot open recording file"; return false; }
    std::string line;
    if (!std::getline(file, line) || line != "timestamp_ns,frame,substep,pressed,player") { error = "Unsupported recording header"; return false; }
    std::vector<ClickSample> parsed;
    while (std::getline(file, line)) {
        if (parsed.size() >= kMaxEvents) { error = "Recording exceeds event limit"; return false; }
        std::istringstream row(line);
        std::string fields[5];
        for (int i = 0; i < 5; ++i) if (!std::getline(row, fields[i], ',')) { error = "Malformed CSV row"; return false; }
        std::string extra;
        if (std::getline(row, extra, ',')) { error = "Unexpected CSV field"; return false; }
        try {
            std::size_t used = 0;
            ClickSample e;
            e.timestampNs = std::stoull(fields[0], &used); if (used != fields[0].size()) throw 1;
            auto frame = std::stoul(fields[1], &used); if (used != fields[1].size() || frame > std::numeric_limits<std::uint32_t>::max()) throw 1;
            e.frame = static_cast<std::uint32_t>(frame);
            auto substep = std::stoul(fields[2], &used); if (used != fields[2].size() || substep > std::numeric_limits<std::uint16_t>::max()) throw 1;
            e.substep = static_cast<std::uint16_t>(substep);
            auto pressed = std::stoul(fields[3], &used); if (used != fields[3].size() || pressed > 1) throw 1;
            e.pressed = pressed == 1;
            auto player = std::stoul(fields[4], &used); if (used != fields[4].size() || player < 1 || player > 2) throw 1;
            e.player = static_cast<std::uint8_t>(player);
            if (!parsed.empty() && e.timestampNs < parsed.back().timestampNs) { error = "Timestamps are not ordered"; return false; }
            parsed.push_back(e);
        } catch (...) { error = "Invalid numeric value in CSV"; return false; }
    }
    if (file.bad()) { error = "Failed while reading recording"; return false; }
    m_events.swap(parsed); stop(); return true;
}

} // namespace fwa
