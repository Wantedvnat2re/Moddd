# Resources

Place original icons, textures and other project-owned UI assets here.
No FB Counter assets are included.
