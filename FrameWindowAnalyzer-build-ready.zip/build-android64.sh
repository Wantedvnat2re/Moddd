#!/usr/bin/env bash
set -euo pipefail

# Requires Geode CLI, Android NDK, and the Geode Android64 SDK binaries.
# Run this script from the project root.
command -v geode >/dev/null 2>&1 || {
  echo "Geode CLI not found. Install Geode CLI first: https://geode-sdk.org/" >&2
  exit 127
}

geode sdk install-binaries -p android64 --version "5.11.2"
geode build -p android64

mapfile -t packages < <(find . -type f -name '*.geode' -not -path './.git/*' -print)
if [[ ${#packages[@]} -eq 0 ]]; then
  echo "Build completed but no .geode package was found." >&2
  exit 1
fi
printf 'Built package(s):\n'
printf ' - %s\n' "${packages[@]}"
