#pragma once
#include <string>

namespace fwa {
struct Config {
    int scanProfile = 2;
    double fps = 60.0;
    bool adaptive = true;
    bool capturePlayer1 = true;
    bool capturePlayer2 = true;
    bool autoSave = true;
    static Config load(const std::string& path);
    bool save(const std::string& path, std::string& error) const;
};
}
