#pragma once
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace fwa {

// A candidate interval must come from an authoritative game-state validator.
// The planner optimizes supplied candidates; it does not infer safe gameplay.
struct CandidateWindow {
    std::uint64_t centerNs = 0;
    std::uint64_t halfWidthNs = 0;
    double confidence = 0.0;
    bool validated = false;
};
struct RouteStep {
    std::size_t sourceIndex = 0;
    std::uint64_t chosenTimeNs = 0;
};
struct RouteResult {
    bool found = false;
    double score = 0.0;
    std::string status = "not-run";
    std::vector<RouteStep> steps;
};

class Pathfinder {
public:
    // Finds a monotonic route with a minimum gap between successive windows.
    // Unvalidated windows are rejected unless allowUnvalidated is explicitly true.
    static RouteResult findRoute(const std::vector<std::vector<CandidateWindow>>& stages,
                                 std::uint64_t minimumGapNs,
                                 bool allowUnvalidated = false,
                                 std::size_t maximumStates = 1'000'000);
    static bool validateRoute(const std::vector<std::vector<CandidateWindow>>& stages,
                              const RouteResult& route, std::uint64_t minimumGapNs,
                              std::string& error);
    static bool saveRouteCsv(const std::string& path, const RouteResult& route, std::string& error);
};

} // namespace fwa
