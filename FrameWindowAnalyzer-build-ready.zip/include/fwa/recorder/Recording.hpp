#pragma once
#include "fwa/analyzer/FrameAnalyzer.hpp"
#include <cstdint>
#include <string>
#include <vector>

namespace fwa {

class Recording {
public:
    void begin();
    void pause();
    void resume();
    void stop();
    bool isRecording() const;
    bool isPaused() const;
    void add(ClickSample sample);
    bool edit(std::size_t index, ClickSample sample, std::string& error);
    bool erase(std::size_t index, std::string& error);
    bool shiftFrom(std::size_t index, std::int64_t deltaNs, std::string& error);
    const std::vector<ClickSample>& events() const;
    bool saveCsv(const std::string& path, std::string& error) const;
    bool loadCsv(const std::string& path, std::string& error);

private:
    bool m_recording = false;
    bool m_paused = false;
    std::vector<ClickSample> m_events;
};

} // namespace fwa
