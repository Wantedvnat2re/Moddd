#pragma once
#include <cstdint>
#include <string>
#include <vector>

namespace fwa {

enum class ScanProfile { Fastest, Fast, Balanced, Accurate };
enum class ReanalysisMode { MissingOnly, FromScratch };

struct ClickSample {
    std::uint64_t timestampNs = 0;
    std::uint32_t frame = 0;
    std::uint16_t substep = 0;
    bool pressed = true;
    std::uint8_t player = 1;
};

struct WindowResult {
    std::uint64_t centerNs = 0;
    std::uint64_t widthNs = 0;
    double widthFrames = 0.0;
    double widthMs = 0.0;
    bool verified = false;
    std::string status = "unverified";
};

struct AnalysisSummary {
    std::size_t inputEvents = 0;
    std::size_t clickPresses = 0;
    std::size_t invalidEvents = 0;
    std::size_t releases = 0;
    std::uint64_t durationNs = 0;
    double meanIntervalMs = 0.0;
    double medianIntervalMs = 0.0;
    double measuredEventsPerSecond = 0.0;
    std::vector<WindowResult> windows;
};

struct AnalysisOptions {
    double fps = 60.0;
    ScanProfile profile = ScanProfile::Balanced;
    ReanalysisMode mode = ReanalysisMode::FromScratch;
    bool adaptive = true;
    std::size_t maximumEvents = 2'000'000;
};

class FrameAnalyzer {
public:
    static AnalysisSummary analyzeRecordedTiming(const std::vector<ClickSample>& events, double fps, ScanProfile profile);
    static AnalysisSummary analyze(const std::vector<ClickSample>& events, const AnalysisOptions& options,
        const std::vector<WindowResult>& previous = {});
    static const char* profileName(ScanProfile profile);
};

} // namespace fwa
